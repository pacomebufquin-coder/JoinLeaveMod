package com.pacome.joinleave.mixin;

import net.minecraft.server.PlayerManager;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(PlayerManager.class)
public class JoinPlayerManagerMixin {

    // Supprime le message de connexion
    @Redirect(
            method = "onPlayerConnect",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/server/PlayerManager;broadcast(Lnet/minecraft/text/Text;Z)V"
            )
    )
    private void cancelJoinBroadcast(PlayerManager manager, Text text, boolean overlay) {
        // rien
    }


    // Supprime le message de déconnexion
    @Redirect(
            method = "remove",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/server/PlayerManager;broadcast(Lnet/minecraft/text/Text;Z)V"
            )
    )
    private void cancelLeaveBroadcast(PlayerManager manager, Text text, boolean overlay) {
        // rien
    }
}