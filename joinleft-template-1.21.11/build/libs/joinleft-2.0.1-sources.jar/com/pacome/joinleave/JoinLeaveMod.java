package com.pacome.joinleave;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.jspecify.annotations.NonNull;

public class JoinLeaveMod implements ModInitializer {

    @Override
    public void onInitialize() {

        System.out.println("[JoinLeaveMod] Mod chargé !");

        // Connexion joueur
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {

            class_3222 player = handler.field_14140;

            System.out.println("[JoinLeaveMod] Joueur connecté : " + player.method_5477().getString());


            server.method_3760().method_43514(
                    class_2561.method_43470("§c➜ §e" + player.method_5477().getString() + "§c a rejoint le serveur !"),
                    false
            );

            // Son pour tout le serveur + la personne qui vient de rejoindre
            server.method_3760().method_14571().forEach(p -> {

                server.method_3847(class_1937.field_25179).method_8396(
                        null,
                        p.method_24515(),
                        class_3417.field_34376,
                        class_3419.field_15250,
                        1.0F,
                        1.0F
                );

            });

            System.out.println("[JoinLeaveMod] Son JOIN joué !");
        });


        // Déconnexion joueur
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {

            class_3222 player = handler.field_14140;

            System.out.println("[JoinLeaveMod] Joueur déconnecté : " + player.method_5477().getString());
            server.method_3760().method_43514(
                    class_2561.method_43470("§c➜ §e" + player.method_5477().getString() + "§c a quitté le serveur !"),
                    false
            );

            // Les joueurs restants entendent le son
            server.method_3760().method_14571().forEach(p -> {

                server.method_3847(class_1937.field_25179).method_8396(
                        null,
                        p.method_24515(),
                        class_3417.field_14675,
                        class_3419.field_15250,
                        1.0F,
                        1.0F
                );

            });

            System.out.println("[JoinLeaveMod] Son LEAVE joué !");
        });
    }

    private static @NonNull String getString() {
        return "&e";
    }
}