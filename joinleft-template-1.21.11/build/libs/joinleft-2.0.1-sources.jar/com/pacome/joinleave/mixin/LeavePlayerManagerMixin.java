package com.pacome.joinleave.mixin;

import net.minecraft.class_2561;
import net.minecraft.class_3324;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3324.class)
public class LeavePlayerManagerMixin {

    @Inject(
            method = "broadcast(Lnet/minecraft/text/Text;Z)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void removeVanillaLeaveMessage(class_2561 message, boolean overlay, CallbackInfo ci) {

        String msg = message.getString();

        if (msg.contains("left the game")) {
            ci.cancel();
        }
    }
}