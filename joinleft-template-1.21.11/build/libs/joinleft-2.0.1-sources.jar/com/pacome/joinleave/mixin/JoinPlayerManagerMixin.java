package com.pacome.joinleave.mixin;

import net.minecraft.class_2561;
import net.minecraft.class_3324;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_3324.class)
public class JoinPlayerManagerMixin {

    // Modification du message de connexion
    @Redirect(
            method = "onPlayerConnect",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/server/PlayerManager;broadcast(Lnet/minecraft/text/Text;Z)V"
            )
    )
    private void modifyJoinMessage(class_3324 manager, class_2561 text, boolean overlay) {

        manager.method_43514(
                class_2561.method_43470("§6Bienvenue sur le serveur !"),
                false
        );
    }
}