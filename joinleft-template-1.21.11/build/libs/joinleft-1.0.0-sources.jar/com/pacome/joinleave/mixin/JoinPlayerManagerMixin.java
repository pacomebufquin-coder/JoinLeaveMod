package com.pacome.joinleave.mixin;

import net.minecraft.class_2561;
import net.minecraft.class_3324;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_3324.class)
public class JoinPlayerManagerMixin {

    // Supprime le message de connexion
    @Redirect(
            method = "onPlayerConnect",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/server/PlayerManager;broadcast(Lnet/minecraft/text/Text;Z)V"
            )
    )
    private void cancelJoinBroadcast(class_3324 manager, class_2561 text, boolean overlay) {
        // rien
    }


    // Supprime le message de déconnexion
    @Redirect(
            method = "remove",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/server/PlayerManager;broadcast(Lnet/minecraft/text/Text;Z)V"
            )
    )
    private void cancelLeaveBroadcast(class_3324 manager, class_2561 text, boolean overlay) {
        // rien
    }
}